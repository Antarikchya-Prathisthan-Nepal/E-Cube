# E-cube-webserver-CSV-export
A python script to extract E-cube data in CSV format with timestamps
